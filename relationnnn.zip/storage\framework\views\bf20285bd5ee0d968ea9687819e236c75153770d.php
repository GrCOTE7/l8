
<?php $__env->startSection('css'); ?>
    <style>
        .card-footer {
            justify-content: center;
            align-items: center;
            padding: 0.4em;
        }
        select, .is-info {
            margin: 0.3em;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session()->has('info')): ?>
        <div class="notification is-success">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <header class="card-header">
            <p class="card-header-title">Films</p>
            <div class="select">
                <select onchange="window.location.href = this.value">
                    <option value="<?php echo e(route('films.index')); ?>" <?php if (! ($slug)): ?> selected <?php endif; ?>>Toutes catégories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(route('films.category', $category->slug)); ?>" <?php echo e($slug == $category->slug ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <a class="button is-info" href="<?php echo e(route('films.create')); ?>">Créer un film</a>
        </header>
        <div class="card-content">
            <div class="content">
                <table class="table is-hoverable">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr <?php if($film->deleted_at): ?> class="has-background-grey-lighter" <?php endif; ?>>
                            <td><strong><?php echo e($film->title); ?></strong></td>
                                <td>
                                    <?php if($film->deleted_at): ?>
                                        <form action="<?php echo e(route('films.restore', $film->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button class="button is-primary" type="submit">Restaurer</button>
                                        </form>
                                    <?php else: ?>
                                        <a class="button is-primary" href="<?php echo e(route('films.show', $film->id)); ?>">Voir</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($film->deleted_at): ?>
                                    <?php else: ?>
                                        <a class="button is-warning" href="<?php echo e(route('films.edit', $film->id)); ?>">Modifier</a>
                                    <?php endif; ?>
                                </td>
                            <td>
                                <form action="<?php echo e(route($film->deleted_at? 'films.force.destroy' : 'films.destroy', $film->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="button is-danger" type="submit">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <footer class="card-footer is-centered">
            <?php echo e($films->links()); ?>

        </footer>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel8\resources\views/index.blade.php ENDPATH**/ ?>